const navs = document.getElementById("nav")
function openNav() {
  navs.classList.toggle("sidebar")
  console.log('open')
  
}

function closeNav() {
  navs.classList.toggle("sidebar");
 
}
